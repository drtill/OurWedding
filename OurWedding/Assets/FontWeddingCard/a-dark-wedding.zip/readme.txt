﻿______ _____ _   _ _____ ___________  ___  ___  ___  ___  
|  ___|  _  | \ | |_   _|  _  | ___ \/ _ \ |  \/  | / _ \ 
| |_  | | | |  \| | | | | | | | |_/ / /_\ \| .  . |/ /_\ \
|  _| | | | | . ` | | | | | | |    /|  _  || |\/| ||  _  |
| |   \ \_/ / |\  | | | \ \_/ / |\ \| | | || |  | || | | |
\_|    \___/\_| \_/ \_/  \___/\_| \_\_| |_/\_|  |_/\_| |_/
                                                          
A Dark Wedding.

FONT DONE BY (c) MIKE LARSSON 2007.

Shareware. 
If youre going to use it for
commercial things, contact me :

mr.fisk@gmail.com
www.fontorama.net